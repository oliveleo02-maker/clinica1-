SITE DRA. KAMILA RICARDO

Para publicar no GitHub Pages, envie o index.html e a pasta images inteira.
O arquivo index.html já aponta para as imagens dentro de images/.
WhatsApp configurado: (91) 99382-8511.
